package com.songsoul.carrentalapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;

import java.util.ArrayList;
import java.util.List;


public class RentalListActivity extends AppCompatActivity {
    private MaterialToolbar toolbar;
    private RecyclerView carsRecyclerView;

    private UserDatabaseHelper dbHelper;
    private TextView locationDates;
    private SessionManager session;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rental_list);

        dbHelper = new UserDatabaseHelper(this);
        session = new SessionManager(this);


        try {
            dbHelper.insertSampleCars();
        } catch (Exception e) {
            Toast.makeText(this, "Error initializing car data: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

        locationDates = findViewById(R.id.locationDates);
        carsRecyclerView = findViewById(R.id.carsRecyclerView);
        carsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> {
            Intent intent = new Intent(RentalListActivity.this, LandingPageActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
        loadCars();

    }

    public void onRentClick(Car car) {
        Intent intent = new Intent(RentalListActivity.this, BookCarActivity.class);
        intent.putExtra("carId", car.getId());
        startActivity(intent);
    }


    private void loadCars() {
        List<Car> carList = new ArrayList<>();

        try {
            Cursor cursor = dbHelper.getAllCars();

            int idIndex = cursor.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_ID);
            int modelIndex = cursor.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_MODEL);
            int seatsIndex = cursor.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_SEATS);
            int speedIndex = cursor.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_SPEED);
            int priceIndex = cursor.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_PRICE);
            int imageIndex = cursor.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_IMAGE);
            int locationIndex = cursor.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_LOCATION);
            int datesIndex = cursor.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_DATES);

            if (cursor.moveToFirst()) {
                do {
                    if (carList.isEmpty()) {
                        String location = cursor.getString(locationIndex);
                        String dates = cursor.getString(datesIndex);
                        locationDates.setText(location + "\n" + dates);
                    }

                    Car car = new Car(
                            cursor.getInt(idIndex),
                            cursor.getString(modelIndex),
                            cursor.getInt(seatsIndex),
                            cursor.getInt(speedIndex),
                            cursor.getDouble(priceIndex),
                            cursor.getString(imageIndex),
                            cursor.getString(locationIndex),
                            cursor.getString(datesIndex)
                    );
                    carList.add(car);
                } while (cursor.moveToNext());
            }
            cursor.close();

            CarAdapter adapter = new CarAdapter(this, carList, CarAdapter.Mode.RENT, this::onRentClick);
            carsRecyclerView.setAdapter(adapter);
        } catch (Exception e) {
            Toast.makeText(this, "Error loading cars: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

}