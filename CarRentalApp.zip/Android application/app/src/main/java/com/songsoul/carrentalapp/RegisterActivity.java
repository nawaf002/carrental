package com.songsoul.carrentalapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    UserDatabaseHelper dbHelper;

    EditText name, email, phone, password, confirmPassword;
    Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        dbHelper = new UserDatabaseHelper(this);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmPassword);
        registerButton = findViewById(R.id.registerButton);

        registerButton.setOnClickListener(v -> {
            String nameInput = name.getText().toString().trim();
            String emailInput = email.getText().toString().trim();
            String phoneInput = phone.getText().toString().trim();
            String passInput = password.getText().toString();
            String confirmPassInput = confirmPassword.getText().toString();

            // === Validations ===

            if (nameInput.length() < 4) {
                name.setError("Name must be at least 4 characters");
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
                email.setError("Invalid email format");
                return;
            }

            if (!phoneInput.startsWith("+968") || phoneInput.length() < 8 || !phoneInput.matches("\\+968\\d{5,}")) {
                phone.setError("Phone must start with +968 and contain valid digits");
                return;
            }

            // First check length and allowed characters (letters, digits, special chars)
            if (!passInput.matches("[A-Za-z\\d!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/]{8}")) {
                password.setError("Password must be exactly 8 characters with letters, digits, and special characters only");
                return;
            }

            // Check for at least one letter
            if (!passInput.matches(".*[A-Za-z].*")) {
                password.setError("Password must contain at least one letter");
                return;
            }

            // Check for at least one digit
            if (!passInput.matches(".*\\d.*")) {
                password.setError("Password must contain at least one digit");
                return;
            }

            // Check for at least one special character
            if (!passInput.matches(".*[!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/].*")) {
                password.setError("Password must contain at least one special character");
                return;
            }


            if (!passInput.equals(confirmPassInput)) {
                confirmPassword.setError("Passwords do not match");
                return;
            }


            if (dbHelper.userExists(emailInput)) {
                Toast.makeText(this, "User already registered with this email", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = dbHelper.registerUser(nameInput, emailInput, phoneInput, passInput);
            if (success) {
                Toast.makeText(this, "Registered successfully!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Registration failed!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
