package com.songsoul.carrentalapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class LandingPageActivity extends AppCompatActivity implements View.OnClickListener {

    private CardView cardViewAllCars, cardViewYourCars, cardViewRemoveCar, cardViewMembers, cardViewDummy;
    private FloatingActionButton fabMessage;
    private SessionManager sessionManager;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);

        sessionManager = new SessionManager(this);

        cardViewAllCars = findViewById(R.id.cardViewAllCars);
        cardViewYourCars = findViewById(R.id.cardViewYourCars);
        cardViewRemoveCar = findViewById(R.id.cardViewRemoveCar);
        cardViewMembers = findViewById(R.id.cardViewMembers);
        cardViewDummy = findViewById(R.id.cardViewDummy);
        fabMessage = findViewById(R.id.fabMessage);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Car Rental");
        }

        cardViewAllCars.setOnClickListener(this);
        cardViewYourCars.setOnClickListener(this);
        cardViewRemoveCar.setOnClickListener(this);
        cardViewMembers.setOnClickListener(this);
        cardViewDummy.setOnClickListener(this);
        fabMessage.setOnClickListener(this);

        toolbar.setNavigationOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if (id == R.id.cardViewAllCars) {
            startActivity(new Intent(LandingPageActivity.this, RentalListActivity.class));
        } else if (id == R.id.cardViewYourCars) {
            startActivity(new Intent(LandingPageActivity.this, ViewYourCarsActivity.class));
        } else if (id == R.id.cardViewRemoveCar) {
            startActivity(new Intent(LandingPageActivity.this, RemoveRentedCarsActivity.class));
        }
        else if (id == R.id.cardViewMembers) {
            startActivity(new Intent(this, ViewMembersActivity.class));
        }
        else if (id == R.id.cardViewDummy) {
            Toast.makeText(this, "Dummy feature", Toast.LENGTH_SHORT).show();
        }else if (id == R.id.fabMessage) {
            startActivity(new Intent(this, ContactUsActivity.class));
        }

    }
}