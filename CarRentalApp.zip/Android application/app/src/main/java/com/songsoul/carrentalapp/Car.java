package com.songsoul.carrentalapp;

import android.database.Cursor;

import java.io.Serializable;

public class Car implements Serializable {
    private int id;
    private String model;
    private int seats;
    private int speed;
    private double price;
    private String imagePath;
    private String location;
    private String dates;

    public Car(int id, String model, int seats, int speed, double price,
               String imagePath, String location, String dates) {
        this.id = id;
        this.model = model;
        this.seats = seats;
        this.speed = speed;
        this.price = price;
        this.imagePath = imagePath;
        this.location = location;
        this.dates = dates;
    }


    public static Car fromCursor(Cursor c) {
        return new Car(
                c.getInt(c.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_ID)),
                c.getString(c.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_MODEL)),
                c.getInt(c.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_SEATS)),
                c.getInt(c.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_SPEED)),
                c.getDouble(c.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_PRICE)),
                c.getString(c.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_IMAGE)),
                c.getString(c.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_LOCATION)),
                c.getString(c.getColumnIndexOrThrow(UserDatabaseHelper.COL_CAR_DATES))
        );
    }

    // Getters
    public int getId() { return id; }
    public String getModel() { return model; }
    public int getSeats() { return seats; }
    public int getSpeed() { return speed; }
    public double getPrice() { return price; }
    public String getImagePath() { return imagePath; }
    public String getLocation() { return location; }
    public String getDates() { return dates; }
}
