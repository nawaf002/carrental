package com.songsoul.carrentalapp;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import java.util.ArrayList;
import java.util.List;

public class RemoveRentedCarsActivity extends AppCompatActivity {

    private UserDatabaseHelper dbHelper;
    private SessionManager session;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_rented_cars);

        dbHelper = new UserDatabaseHelper(this);
        session = new SessionManager(this);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.removeCarsRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadRentedCars();
    }

    private void loadRentedCars() {
        String email = session.getUserEmail();
        if (email == null) return;

        Cursor c = dbHelper.getRentedCars(email);
        List<Car> cars = new ArrayList<>();
        while (c.moveToNext()) {
            cars.add(Car.fromCursor(c));
        }
        c.close();

        CarAdapter adapter = new CarAdapter(this, cars, CarAdapter.Mode.REMOVE, car -> {
            boolean success = dbHelper.removeRentedCar(email, car.getId());
            Toast.makeText(this, success ? "Car removed!" : "Failed to remove", Toast.LENGTH_SHORT).show();
            loadRentedCars();
        });

        recyclerView.setAdapter(adapter);
    }
}
