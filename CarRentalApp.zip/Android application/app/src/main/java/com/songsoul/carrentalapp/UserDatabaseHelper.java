package com.songsoul.carrentalapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "CarRental.db";
    public static final int DATABASE_VERSION = 2; // Increment version number to trigger upgrade

    public static final String TABLE_USERS = "Users";
    public static final String COL_ID = "id";
    public static final String COL_NAME = "name";
    public static final String COL_EMAIL = "email";
    public static final String COL_PHONE = "phone";
    public static final String COL_PASSWORD = "password";
    public static final String TABLE_CARS = "Cars";
    public static final String COL_CAR_ID = "car_id";
    public static final String COL_CAR_MODEL = "model";
    public static final String COL_CAR_SEATS = "seats";
    public static final String COL_CAR_SPEED = "speed";
    public static final String COL_CAR_PRICE = "price";
    public static final String COL_CAR_IMAGE = "image_path";
    public static final String COL_CAR_LOCATION = "location";
    public static final String COL_CAR_DATES = "dates";
    public static final String TABLE_RENTALS = "Rentals";
    public static final String COL_RENTAL_ID = "rental_id";
    public static final String COL_RENTAL_USER = "user_email";
    public static final String COL_RENTAL_CAR  = "car_id";
    public UserDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create table
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT, " +
                COL_EMAIL + " TEXT UNIQUE, " +
                COL_PHONE + " TEXT, " +
                COL_PASSWORD + " TEXT)";
        String createCarsTable = "CREATE TABLE " + TABLE_CARS + " (" +
                COL_CAR_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CAR_MODEL + " TEXT, " +
                COL_CAR_SEATS + " INTEGER, " +
                COL_CAR_SPEED + " INTEGER, " +
                COL_CAR_PRICE + " REAL, " +
                COL_CAR_IMAGE + " TEXT, " +
                COL_CAR_LOCATION + " TEXT, " +
                COL_CAR_DATES + " TEXT)";
        String createRentals = "CREATE TABLE " + TABLE_RENTALS + " (" +
                COL_RENTAL_ID    + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_RENTAL_USER  + " TEXT, " +
                COL_RENTAL_CAR   + " INTEGER)";
        db.execSQL(createRentals);
        // Execute both create table statements
        db.execSQL(createUsersTable);
        db.execSQL(createCarsTable);
    }
    private void ensureRentalsTable(SQLiteDatabase db) {
        if (!isTableExists(db, TABLE_RENTALS)) {
            String createRentals = "CREATE TABLE " + TABLE_RENTALS + " (" +
                    COL_RENTAL_ID    + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_RENTAL_USER  + " TEXT, " +
                    COL_RENTAL_CAR   + " INTEGER)";
            db.execSQL(createRentals);
        }
    }
    public boolean rentCar(String userEmail, int carId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ensureRentalsTable(db);

        Cursor cursor = db.query(
                TABLE_RENTALS,
                null,
                COL_RENTAL_USER + "=? AND " + COL_RENTAL_CAR + "=?",
                new String[]{userEmail, String.valueOf(carId)},
                null, null, null
        );

        boolean alreadyExists = cursor.getCount() > 0;
        cursor.close();

        if (alreadyExists) {
            return false;
        }
        ContentValues cv = new ContentValues();
        cv.put(COL_RENTAL_USER, userEmail);
        cv.put(COL_RENTAL_CAR,  carId);
        long id = db.insert(TABLE_RENTALS, null, cv);
        return id != -1;
    }

    public Cursor getRentedCars(String userEmail) {
        SQLiteDatabase db = this.getReadableDatabase();
        ensureRentalsTable(db);
        String sql = "SELECT c.* FROM " + TABLE_CARS + " c"
                + " INNER JOIN " + TABLE_RENTALS + " r"
                + "   ON c." + COL_CAR_ID + " = r." + COL_RENTAL_CAR
                + " WHERE r." + COL_RENTAL_USER + " = ?";
        return db.rawQuery(sql, new String[]{ userEmail });
    }
    public Car getCarById(int carId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(TABLE_CARS, null, COL_CAR_ID + "=?",
                new String[]{String.valueOf(carId)}, null, null, null);
        if (c.moveToFirst()) {
            Car car = Car.fromCursor(c);
            c.close();
            return car;
        }
        c.close();
        return null;
    }

    public void insertSampleCars() {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_CARS, null);
        cursor.moveToFirst();
        int count = cursor.getInt(0);
        cursor.close();

        if (count == 0) {
            insertCar(db, "Tesla Model S", 5, 149, 12, "download", "Muscat", "Jan 17 2022 - Jan 18 2022");
            insertCar(db, "Toyota Civic rs", 5, 200, 10, "civic", "Sur", "Jan 17 2022 - Jan 18 2022");
            insertCar(db, "Ford Mustang 1967", 5, 140, 13, "ms", "Rustaq", "Jan 17 2022 - Jan 18 2022");
            insertCar(db, "BMW XI", 5, 155, 11, "bmwss", "Salalah", "Jan 17 2022 - Jan 18 2022");
        }
    }

    public boolean removeRentedCar(String email, int carId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_RENTALS, COL_RENTAL_USER + "=? AND " + COL_RENTAL_CAR + "=?",
                new String[]{email, String.valueOf(carId)}) > 0;
    }


    private boolean isTableExists(SQLiteDatabase db, String tableName) {
        Cursor cursor = db.rawQuery(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                new String[]{tableName}
        );
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    private void insertCar(SQLiteDatabase db, String model, int seats, int speed, double price,
                           String imagePath, String location, String dates) {
        ContentValues cv = new ContentValues();
        cv.put(COL_CAR_MODEL, model);
        cv.put(COL_CAR_SEATS, seats);
        cv.put(COL_CAR_SPEED, speed);
        cv.put(COL_CAR_PRICE, price);
        cv.put(COL_CAR_IMAGE, imagePath);
        cv.put(COL_CAR_LOCATION, location);
        cv.put(COL_CAR_DATES, dates);
        db.insert(TABLE_CARS, null, cv);
    }

    public Cursor getAllCars() {
        SQLiteDatabase db = this.getReadableDatabase();

        if (!isTableExists(db, TABLE_CARS)) {
            String createCarsTable = "CREATE TABLE " + TABLE_CARS + " (" +
                    COL_CAR_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_CAR_MODEL + " TEXT, " +
                    COL_CAR_SEATS + " INTEGER, " +
                    COL_CAR_SPEED + " INTEGER, " +
                    COL_CAR_PRICE + " REAL, " +
                    COL_CAR_IMAGE + " TEXT, " +
                    COL_CAR_LOCATION + " TEXT, " +
                    COL_CAR_DATES + " TEXT)";
            db.execSQL(createCarsTable);
        }

        return db.query(TABLE_CARS,
                null, null, null, null, null, null);
    }
    public boolean isCarRented(int carId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_RENTALS + " WHERE " + COL_RENTAL_CAR + "=?",
                new String[]{String.valueOf(carId)}
        );
        boolean isRented = cursor.getCount() > 0;
        cursor.close();
        return isRented;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (!isTableExists(db, TABLE_CARS)) {
            String createCarsTable = "CREATE TABLE " + TABLE_CARS + " (" +
                    COL_CAR_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_CAR_MODEL + " TEXT, " +
                    COL_CAR_SEATS + " INTEGER, " +
                    COL_CAR_SPEED + " INTEGER, " +
                    COL_CAR_PRICE + " REAL, " +
                    COL_CAR_IMAGE + " TEXT, " +
                    COL_CAR_LOCATION + " TEXT, " +
                    COL_CAR_DATES + " TEXT)";
            db.execSQL(createCarsTable);
        }

        // You could also choose to drop and recreate all tables
        // db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        // db.execSQL("DROP TABLE IF EXISTS " + TABLE_CARS);
        // onCreate(db);
    }

    public boolean registerUser(String name, String email, String phone, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME, name);
        cv.put(COL_EMAIL, email);
        cv.put(COL_PHONE, phone);
        cv.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, cv);
        return result != -1;
    }

    public boolean loginUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COL_EMAIL + "=? AND " + COL_PASSWORD + "=?",
                new String[]{email, password});
        boolean result = cursor.getCount() > 0;
        cursor.close();
        return result;
    }

    public boolean userExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                " WHERE " + COL_EMAIL + "=?", new String[]{email});
        boolean result = cursor.getCount() > 0;
        cursor.close();
        return result;
    }

    public String getUserNameByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COL_NAME + " FROM " + TABLE_USERS + " WHERE " + COL_EMAIL + "=?", new String[]{email});
        if (cursor.moveToFirst()) {
            String name = cursor.getString(0);
            cursor.close();
            return name;
        }
        cursor.close();
        return null;
    }
}