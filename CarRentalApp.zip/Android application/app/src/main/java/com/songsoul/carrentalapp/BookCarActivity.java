package com.songsoul.carrentalapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;

public class BookCarActivity extends AppCompatActivity {

    private EditText etDays, etCardNumber, etCardExpiry, etCardCVV;
    private RadioGroup paymentGroup;
    private LinearLayout cardLayout;
    private TextView tvTotal;
    private Button btnConfirm;

    private double carPrice;
    private Car selectedCar;
    private SessionManager session;
    private UserDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_car);

        int carId = getIntent().getIntExtra("carId", -1);
        if (carId == -1) {
            Toast.makeText(this, "Invalid car selected", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        dbHelper = new UserDatabaseHelper(this);
        session = new SessionManager(this);

        Car car = dbHelper.getCarById(carId);
        if (car == null) {
            Toast.makeText(this, "Car not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        selectedCar = car;
        carPrice = selectedCar.getPrice();

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        etDays = findViewById(R.id.etDays);
        etCardNumber = findViewById(R.id.etCardNumber);
        etCardExpiry = findViewById(R.id.etCardExpiry);
        etCardCVV = findViewById(R.id.etCardCVV);
        paymentGroup = findViewById(R.id.paymentGroup);
        cardLayout = findViewById(R.id.cardLayout);
        tvTotal = findViewById(R.id.tvTotal);
        btnConfirm = findViewById(R.id.btnConfirm);

        paymentGroup.setOnCheckedChangeListener((group, checkedId) -> {
            cardLayout.setVisibility(checkedId == R.id.radioCard ? View.VISIBLE : View.GONE);
        });

        btnConfirm.setOnClickListener(v -> confirmBooking());
    }

    private void confirmBooking() {
        String daysStr = etDays.getText().toString();
        if (TextUtils.isEmpty(daysStr)) {
            etDays.setError("Enter number of days");
            return;
        }

        int days = Integer.parseInt(daysStr);
        double total = carPrice * days;
        tvTotal.setText("Total: OMR " + total);

        int paymentId = paymentGroup.getCheckedRadioButtonId();
        if (paymentId == -1) {
            Toast.makeText(this, "Select a payment method", Toast.LENGTH_SHORT).show();
            return;
        }

        if (paymentId == R.id.radioCard) {
            if (TextUtils.isEmpty(etCardNumber.getText()) ||
                    TextUtils.isEmpty(etCardExpiry.getText()) ||
                    TextUtils.isEmpty(etCardCVV.getText())) {
                Toast.makeText(this, "Fill card details", Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this, "Payment of OMR " + total + " confirmed via Card!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Pay OMR " + total + " in cash at pickup!", Toast.LENGTH_LONG).show();
        }

        dbHelper.rentCar(session.getUserEmail(), selectedCar.getId());
        finish();
    }
}
