package com.songsoul.carrentalapp;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;

import java.util.ArrayList;
import java.util.List;

public class ViewYourCarsActivity extends AppCompatActivity {

    private UserDatabaseHelper dbHelper;
    private SessionManager session;
    private RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_your_cars);

        dbHelper = new UserDatabaseHelper(this);
        session  = new SessionManager(this);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        rv = findViewById(R.id.yourCarsRecyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));

        loadYourCars();
    }

    private void loadYourCars() {
        String email = session.getUserEmail();
        if (email == null) return;

        Cursor c = dbHelper.getRentedCars(email);
        List<Car> cars = new ArrayList<>();
        while (c.moveToNext()) {
            cars.add(Car.fromCursor(c));
        }
        c.close();

        CarAdapter adapter = new CarAdapter(this, cars, CarAdapter.Mode.NONE, null);
        rv.setAdapter(adapter);
    }
}

