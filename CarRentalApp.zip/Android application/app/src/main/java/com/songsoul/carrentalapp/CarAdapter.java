package com.songsoul.carrentalapp;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class CarAdapter extends RecyclerView.Adapter<CarAdapter.CarViewHolder> {

    public interface OnRentClickListener {
        void onRentClick(Car car);
    }

    private Context context;
    private List<Car> carList;
    private Mode mode;
    private UserDatabaseHelper dbHelper;
    private OnRentClickListener rentListener;

    public enum Mode {
        RENT, REMOVE, NONE
    }

    public CarAdapter(Context context, List<Car> carList, Mode mode, OnRentClickListener rentListener) {
        this.context = context;
        this.carList = (carList != null) ? carList : new ArrayList<>();
        this.mode = mode;
        this.rentListener = rentListener;
        this.dbHelper = new UserDatabaseHelper(context);
    }

    @NonNull
    @Override
    public CarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.car_item, parent, false);
        return new CarViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CarViewHolder holder, int pos) {
        Car car = carList.get(pos);

        holder.carModel.setText(car.getModel());
        holder.carSeats.setText(car.getSeats() + " Seat");
        holder.carSpeed.setText(car.getSpeed() + " mph");
        holder.carPrice.setText(String.format("OMR %.0f/Day", car.getPrice()));

        String filename = car.getImagePath();
//        Log.d("CarAdapter", "Image path: " + filename + ", Resource ID: " + resId);

        if (filename != null && !filename.isEmpty()) {
            int resId = context.getResources().getIdentifier(
                    filename,
                    "drawable", context.getPackageName()
            );

            Glide.with(context)
                    .load(resId != 0 ? resId : R.drawable.download)
                    .placeholder(R.drawable.download)
                    .error(R.drawable.download)
                    .into(holder.carImage);
        } else {
            holder.carImage.setImageResource(R.drawable.download);
        }


        // Check availability
        boolean isRented = dbHelper.isCarRented(car.getId());

        holder.availability.setText(isRented ? "Not Available" : "Available");
        holder.availability.setTextColor(context.getResources().getColor(
                isRented ? android.R.color.holo_red_light : android.R.color.holo_green_light
        ));

        // Handle button visibility and behavior
        if (mode == Mode.RENT) {
            holder.rentButton.setVisibility(View.VISIBLE);
            holder.rentButton.setText("Rent Now");
            holder.rentButton.setEnabled(!isRented);
            holder.rentButton.setAlpha(isRented ? 0.5f : 1.0f);
        } else if (mode == Mode.REMOVE) {
            holder.rentButton.setVisibility(View.VISIBLE);
            holder.rentButton.setText("Remove Car");
            holder.rentButton.setEnabled(true);
            holder.rentButton.setAlpha(1.0f);
        } else {
            holder.rentButton.setVisibility(View.GONE);
        }

        holder.rentButton.setOnClickListener(v -> {
            if (rentListener != null) {
                rentListener.onRentClick(car);
            }
        });
    }

    @Override
    public int getItemCount() {
        return carList != null ? carList.size() : 0;
    }

    static class CarViewHolder extends RecyclerView.ViewHolder {
        ImageView carImage;
        TextView carModel, carSeats, carSpeed, carPrice, availability;
        Button rentButton;

        CarViewHolder(View itemView) {
            super(itemView);
            carImage = itemView.findViewById(R.id.carImage);
            carModel = itemView.findViewById(R.id.carModel);
            carSeats = itemView.findViewById(R.id.carSeats);
            carSpeed = itemView.findViewById(R.id.carSpeed);
            carPrice = itemView.findViewById(R.id.carPrice);
            availability = itemView.findViewById(R.id.carAvailability);
            rentButton = itemView.findViewById(R.id.rentButton);
        }
    }
}
